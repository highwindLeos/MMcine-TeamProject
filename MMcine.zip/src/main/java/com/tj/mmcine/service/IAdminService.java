package com.tj.mmcine.service;

import com.tj.mmcine.model.Admin;

public interface IAdminService {
	public Admin adminLogin(Admin admin);
}
