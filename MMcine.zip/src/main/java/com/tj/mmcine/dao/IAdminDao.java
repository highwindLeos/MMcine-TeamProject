package com.tj.mmcine.dao;

import com.tj.mmcine.model.Admin;


public interface IAdminDao {
	public Admin adminLogin(Admin admin);
}
